"""
Background task processing with Celery
"""
