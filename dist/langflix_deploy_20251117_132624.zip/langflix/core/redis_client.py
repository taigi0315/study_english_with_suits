"""
Redis client for shared job state management in Phase 7 architecture.
"""

import redis
import json
import logging
import time
from typing import Dict, Any, Optional, List
from datetime import datetime, timezone
import os

logger = logging.getLogger(__name__)

class RedisJobManager:
    """Redis-based job state management for Flask-FastAPI communication."""
    
    def __init__(self, redis_url: str = None):
        """Initialize Redis connection."""
        if redis_url is None:
            redis_url = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
        
        try:
            self.redis_client = redis.from_url(redis_url, decode_responses=True)
            # Test connection
            self.redis_client.ping()
            logger.info(f"✅ Redis connected: {redis_url}")
        except Exception as e:
            logger.error(f"❌ Redis connection failed: {e}")
            raise
    
    def create_job(self, job_id: str, job_data: Dict[str, Any]) -> bool:
        """Create a new job in Redis."""
        try:
            job_data['created_at'] = datetime.now(timezone.utc).isoformat()
            job_data['updated_at'] = datetime.now(timezone.utc).isoformat()
            
            # Store job data as JSON
            self.redis_client.hset(f"job:{job_id}", mapping=job_data)
            
            # Set expiration (24 hours)
            self.redis_client.expire(f"job:{job_id}", 86400)
            
            # Add to job list for tracking
            self.redis_client.sadd("jobs:active", job_id)
            
            logger.info(f"✅ Job {job_id} created in Redis")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to create job {job_id}: {e}")
            return False
    
    def update_job(self, job_id: str, updates: Dict[str, Any]) -> bool:
        """Update job data in Redis."""
        try:
            updates['updated_at'] = datetime.now(timezone.utc).isoformat()
            
            # Ensure progress only increases (prevent progress bar from going backwards)
            if 'progress' in updates:
                current_job = self.get_job(job_id)
                if current_job and 'progress' in current_job:
                    current_progress = int(current_job['progress'])
                    new_progress = int(updates['progress'])
                    # Only update if new progress is greater than current
                    if new_progress < current_progress:
                        logger.debug(f"⏭️ Skipping progress update for job {job_id}: {new_progress}% < {current_progress}% (preventing backward progress)")
                        # Remove progress from updates to prevent backward movement
                        updates = {k: v for k, v in updates.items() if k != 'progress'}
                        # But still update other fields like current_step
                        if not updates:
                            return True  # Nothing to update
            
            # Convert all values to strings for Redis storage
            string_updates = {}
            for key, value in updates.items():
                if isinstance(value, (int, float)):
                    string_updates[key] = str(value)
                elif isinstance(value, bool):
                    string_updates[key] = str(value).lower()
                elif isinstance(value, datetime):
                    string_updates[key] = value.isoformat()
                elif isinstance(value, (list, dict)):
                    # Serialize lists and dicts as JSON for proper storage/retrieval
                    string_updates[key] = json.dumps(value, default=str)
                elif value is None:
                    string_updates[key] = "None"
                else:
                    string_updates[key] = str(value)
            
            # Update job data
            self.redis_client.hset(f"job:{job_id}", mapping=string_updates)
            
            logger.debug(f"✅ Job {job_id} updated: {string_updates}")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to update job {job_id}: {e}")
            return False
    
    def get_job(self, job_id: str) -> Optional[Dict[str, Any]]:
        """Get job data from Redis."""
        try:
            job_data = self.redis_client.hgetall(f"job:{job_id}")
            if not job_data:
                return None
            
            # Convert string values back to appropriate types
            if 'progress' in job_data:
                job_data['progress'] = int(job_data['progress'])
            if 'max_expressions' in job_data:
                job_data['max_expressions'] = int(job_data['max_expressions'])
            if 'test_mode' in job_data:
                job_data['test_mode'] = job_data['test_mode'].lower() == 'true'
            if 'no_shorts' in job_data:
                job_data['no_shorts'] = job_data['no_shorts'].lower() == 'true'
            
            # Deserialize JSON fields (expressions, educational_videos, short_videos)
            json_fields = ['expressions', 'educational_videos', 'short_videos']
            for field in json_fields:
                if field in job_data:
                    try:
                        # Try to parse as JSON
                        if job_data[field] and job_data[field] != 'None' and job_data[field] != '[]':
                            job_data[field] = json.loads(job_data[field])
                        else:
                            job_data[field] = []
                    except (json.JSONDecodeError, TypeError):
                        # If parsing fails, try to handle legacy string format
                        if job_data[field] == '[]' or job_data[field] == 'None':
                            job_data[field] = []
                        # Otherwise keep as string (for backwards compatibility)
                        pass
            
            # Handle final_video field (might be "None" string or JSON)
            if 'final_video' in job_data:
                if job_data['final_video'] == 'None' or job_data['final_video'] == '':
                    job_data['final_video'] = None
                else:
                    try:
                        # Try to parse as JSON in case it's a dict
                        job_data['final_video'] = json.loads(job_data['final_video'])
                    except (json.JSONDecodeError, TypeError):
                        # Keep as string if not valid JSON
                        pass
            
            return job_data
        except Exception as e:
            logger.error(f"❌ Failed to get job {job_id}: {e}")
            return None
    
    def get_all_jobs(self) -> Dict[str, Dict[str, Any]]:
        """Get all active jobs."""
        try:
            job_ids = self.redis_client.smembers("jobs:active")
            jobs = {}
            
            for job_id in job_ids:
                job_data = self.get_job(job_id)
                if job_data:
                    jobs[job_id] = job_data
            
            return jobs
        except Exception as e:
            logger.error(f"❌ Failed to get all jobs: {e}")
            return {}
    
    def delete_job(self, job_id: str) -> bool:
        """Delete job from Redis."""
        try:
            # Remove from active jobs set
            self.redis_client.srem("jobs:active", job_id)
            
            # Delete job data
            self.redis_client.delete(f"job:{job_id}")
            
            logger.info(f"✅ Job {job_id} deleted from Redis")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to delete job {job_id}: {e}")
            return False
    
    def cleanup_expired_jobs(self) -> int:
        """Clean up expired jobs."""
        try:
            job_ids = self.redis_client.smembers("jobs:active")
            cleaned_count = 0
            
            for job_id in job_ids:
                # Check if job data exists
                if not self.redis_client.exists(f"job:{job_id}"):
                    # Remove from active jobs set if data doesn't exist
                    self.redis_client.srem("jobs:active", job_id)
                    cleaned_count += 1
                    logger.info(f"Cleaned up orphaned job reference: {job_id}")
            
            logger.info(f"Cleaned up {cleaned_count} expired/orphaned jobs")
            return cleaned_count
        except Exception as e:
            logger.error(f"❌ Failed to cleanup expired jobs: {e}")
            return 0
    
    def cleanup_stale_jobs(self, max_age_hours: int = 24) -> int:
        """Clean up stale jobs older than max_age_hours."""
        try:
            from datetime import datetime, timezone, timedelta
            
            job_ids = self.redis_client.smembers("jobs:active")
            cleaned_count = 0
            cutoff_time = datetime.now(timezone.utc) - timedelta(hours=max_age_hours)
            
            for job_id in job_ids:
                job_data = self.get_job(job_id)
                if job_data and 'created_at' in job_data:
                    try:
                        created_at = datetime.fromisoformat(job_data['created_at'].replace('Z', '+00:00'))
                        if created_at < cutoff_time:
                            self.delete_job(job_id)
                            cleaned_count += 1
                            logger.info(f"Cleaned up stale job: {job_id} (created: {created_at})")
                    except ValueError as e:
                        logger.warning(f"Invalid created_at format for job {job_id}: {e}")
            
            logger.info(f"Cleaned up {cleaned_count} stale jobs")
            return cleaned_count
        except Exception as e:
            logger.error(f"❌ Failed to cleanup stale jobs: {e}")
            return 0
    
    def health_check(self) -> Dict[str, Any]:
        """Check Redis connection health and return status."""
        try:
            # Test basic connectivity
            start_time = time.time()
            self.redis_client.ping()
            ping_time = (time.time() - start_time) * 1000  # Convert to milliseconds
            
            # Get Redis info
            info = self.redis_client.info()
            
            # Count active jobs
            active_jobs_count = self.redis_client.scard("jobs:active")
            
            # Get memory usage
            memory_used = info.get('used_memory_human', 'unknown')
            
            return {
                "status": "healthy",
                "ping_time_ms": round(ping_time, 2),
                "active_jobs": active_jobs_count,
                "memory_used": memory_used,
                "redis_version": info.get('redis_version', 'unknown'),
                "connected_clients": info.get('connected_clients', 0),
                "uptime_seconds": info.get('uptime_in_seconds', 0)
            }
        except Exception as e:
            logger.error(f"❌ Redis health check failed: {e}")
            return {
                "status": "unhealthy",
                "error": str(e),
                "ping_time_ms": None,
                "active_jobs": None
            }
    
    def get_video_cache(self) -> Optional[List[Dict[str, Any]]]:
        """Get cached video metadata."""
        try:
            cached_data = self.redis_client.get("langflix:video_cache:all")
            if cached_data:
                import json
                logger.debug("✅ Video cache hit")
                return json.loads(cached_data)
            logger.debug("❌ Video cache miss")
            return None
        except Exception as e:
            logger.error(f"❌ Failed to get video cache: {e}")
            return None
    
    def set_video_cache(self, videos: List[Dict[str, Any]], ttl: int = 300) -> bool:
        """Set video metadata cache with TTL."""
        try:
            import json
            self.redis_client.setex(
                "langflix:video_cache:all", 
                ttl, 
                json.dumps(videos, default=str)
            )
            logger.info(f"✅ Cached {len(videos)} videos for {ttl} seconds")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to set video cache: {e}")
            return False
    
    def invalidate_video_cache(self) -> bool:
        """Invalidate (delete) video cache."""
        try:
            self.redis_client.delete("langflix:video_cache:all")
            logger.info("✅ Video cache invalidated")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to invalidate video cache: {e}")
            return False

    # Batch Queue Management Methods
    
    def create_batch(self, batch_id: str, videos: List[Dict[str, Any]], config: Dict[str, Any]) -> bool:
        """
        Create a batch with multiple videos.
        
        Args:
            batch_id: Unique batch identifier
            videos: List of video dictionaries with job information
            config: Batch configuration (language_code, language_level, etc.)
            
        Returns:
            True if batch created successfully, False otherwise
        """
        try:
            batch_data = {
                "batch_id": batch_id,
                "status": "PENDING",
                "total_jobs": str(len(videos)),
                "completed_jobs": "0",
                "failed_jobs": "0",
                "created_at": datetime.now(timezone.utc).isoformat(),
                "updated_at": datetime.now(timezone.utc).isoformat(),
                "config": json.dumps(config, default=str)
            }
            
            # Store job IDs list
            job_ids = [video.get('job_id') for video in videos if 'job_id' in video]
            batch_data["jobs"] = json.dumps(job_ids, default=str)
            
            # Store batch data as Hash
            self.redis_client.hset(f"batch:{batch_id}", mapping=batch_data)
            
            # Set expiration (24 hours)
            self.redis_client.expire(f"batch:{batch_id}", 86400)
            
            logger.info(f"✅ Batch {batch_id} created with {len(videos)} jobs")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to create batch {batch_id}: {e}")
            return False
    
    def get_batch_status(self, batch_id: str) -> Optional[Dict[str, Any]]:
        """
        Get batch status with all job information.
        
        Args:
            batch_id: Batch identifier
            
        Returns:
            Dictionary with batch status and all job details, or None if not found
        """
        try:
            batch_data = self.redis_client.hgetall(f"batch:{batch_id}")
            if not batch_data:
                return None
            
            # Deserialize job IDs list
            if 'jobs' in batch_data:
                try:
                    job_ids = json.loads(batch_data['jobs'])
                    batch_data['jobs'] = job_ids
                except (json.JSONDecodeError, TypeError):
                    batch_data['jobs'] = []
            
            # Deserialize config
            if 'config' in batch_data:
                try:
                    batch_data['config'] = json.loads(batch_data['config'])
                except (json.JSONDecodeError, TypeError):
                    batch_data['config'] = {}
            
            # Convert numeric fields
            if 'total_jobs' in batch_data:
                batch_data['total_jobs'] = int(batch_data['total_jobs'])
            if 'completed_jobs' in batch_data:
                batch_data['completed_jobs'] = int(batch_data['completed_jobs'])
            if 'failed_jobs' in batch_data:
                batch_data['failed_jobs'] = int(batch_data['failed_jobs'])
            
            # Get all job details
            jobs = []
            if 'jobs' in batch_data and isinstance(batch_data['jobs'], list):
                for job_id in batch_data['jobs']:
                    job = self.get_job(job_id)
                    if job:
                        jobs.append(job)
            
            batch_data['job_details'] = jobs
            
            return batch_data
        except Exception as e:
            logger.error(f"❌ Failed to get batch status {batch_id}: {e}")
            return None
    
    def update_batch_status(self, batch_id: str, updates: Dict[str, Any]) -> bool:
        """Update batch status and metadata."""
        try:
            updates['updated_at'] = datetime.now(timezone.utc).isoformat()
            
            # Convert values to strings for Redis
            string_updates = {}
            for key, value in updates.items():
                if isinstance(value, (int, float)):
                    string_updates[key] = str(value)
                elif isinstance(value, (list, dict)):
                    string_updates[key] = json.dumps(value, default=str)
                elif value is None:
                    string_updates[key] = "None"
                else:
                    string_updates[key] = str(value)
            
            self.redis_client.hset(f"batch:{batch_id}", mapping=string_updates)
            logger.debug(f"✅ Batch {batch_id} updated")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to update batch {batch_id}: {e}")
            return False
    
    def add_job_to_queue(self, job_id: str) -> bool:
        """
        Add job to FIFO queue using Redis LIST.
        Uses LPUSH to add to the left (queue tail), so RPOP gets oldest first.
        
        Args:
            job_id: Job identifier to add to queue
            
        Returns:
            True if added successfully, False otherwise
        """
        try:
            # Add to queue list (FIFO: LPUSH adds to left, RPOP gets from right)
            self.redis_client.lpush("jobs:queue", job_id)
            logger.debug(f"✅ Job {job_id} added to queue")
            return True
        except Exception as e:
            logger.error(f"❌ Failed to add job {job_id} to queue: {e}")
            return False
    
    def get_next_job_from_queue(self) -> Optional[str]:
        """
        Get next job from queue atomically using RPOP (right pop).
        This removes the job from the queue, ensuring only one processor gets it.
        
        Returns:
            Job ID if available, None if queue is empty
        """
        try:
            job_id = self.redis_client.rpop("jobs:queue")
            if job_id:
                logger.debug(f"✅ Retrieved job {job_id} from queue")
            return job_id
        except Exception as e:
            logger.error(f"❌ Failed to get next job from queue: {e}")
            return None
    
    def get_queue_length(self) -> int:
        """Get number of jobs in queue."""
        try:
            return self.redis_client.llen("jobs:queue")
        except Exception as e:
            logger.error(f"❌ Failed to get queue length: {e}")
            return 0
    
    def mark_job_processing(self, job_id: str) -> bool:
        """
        Mark job as currently processing using SETNX (set if not exists).
        This prevents duplicate processing if multiple processors exist.
        
        Args:
            job_id: Job identifier to mark as processing
            
        Returns:
            True if successfully marked (lock acquired), False if already processing
        """
        try:
            # Use SETNX to set only if not exists (atomic lock)
            result = self.redis_client.setnx("jobs:processing", job_id)
            if result:
                # Set expiration (2 hours) in case processor crashes
                self.redis_client.expire("jobs:processing", 7200)
                logger.info(f"✅ Job {job_id} marked as processing")
                return True
            else:
                logger.debug(f"⚠️ Job processing lock already held by another job")
                return False
        except Exception as e:
            logger.error(f"❌ Failed to mark job {job_id} as processing: {e}")
            return False
    
    def get_currently_processing_job(self) -> Optional[str]:
        """Get currently processing job ID."""
        try:
            job_id = self.redis_client.get("jobs:processing")
            return job_id if job_id else None
        except Exception as e:
            logger.error(f"❌ Failed to get currently processing job: {e}")
            return None
    
    def remove_from_processing(self) -> bool:
        """Remove currently processing job marker."""
        try:
            result = self.redis_client.delete("jobs:processing")
            logger.debug(f"✅ Removed processing job marker")
            return bool(result)
        except Exception as e:
            logger.error(f"❌ Failed to remove processing job marker: {e}")
            return False
    
    def get_all_queued_jobs(self) -> List[str]:
        """
        Get all jobs in QUEUED state for restart recovery.
        
        Returns:
            List of job IDs that are in QUEUED state
        """
        try:
            queued_jobs = []
            job_ids = self.redis_client.smembers("jobs:active")
            
            for job_id in job_ids:
                job = self.get_job(job_id)
                if job and job.get('status') == 'QUEUED':
                    queued_jobs.append(job_id)
            
            return queued_jobs
        except Exception as e:
            logger.error(f"❌ Failed to get queued jobs: {e}")
            return []
    
    def acquire_processor_lock(self) -> bool:
        """
        Acquire processor lock to ensure only one queue processor runs.
        Uses SETNX with expiration for safety.
        
        Returns:
            True if lock acquired, False if already held
        """
        try:
            result = self.redis_client.setnx("jobs:processor_lock", "1")
            if result:
                # Set expiration (1 hour) - processor should renew periodically
                self.redis_client.expire("jobs:processor_lock", 3600)
                logger.info("✅ Processor lock acquired")
                return True
            else:
                logger.debug("⚠️ Processor lock already held by another instance")
                return False
        except Exception as e:
            logger.error(f"❌ Failed to acquire processor lock: {e}")
            return False
    
    def release_processor_lock(self) -> bool:
        """Release processor lock."""
        try:
            result = self.redis_client.delete("jobs:processor_lock")
            logger.info("✅ Processor lock released")
            return bool(result)
        except Exception as e:
            logger.error(f"❌ Failed to release processor lock: {e}")
            return False
    
    def renew_processor_lock(self) -> bool:
        """Renew processor lock expiration."""
        try:
            result = self.redis_client.expire("jobs:processor_lock", 3600)
            return bool(result)
        except Exception as e:
            logger.error(f"❌ Failed to renew processor lock: {e}")
            return False

# Global Redis job manager instance
_redis_job_manager: Optional[RedisJobManager] = None

def get_redis_job_manager() -> RedisJobManager:
    """Get global Redis job manager instance."""
    global _redis_job_manager
    if _redis_job_manager is None:
        _redis_job_manager = RedisJobManager()
    return _redis_job_manager

def init_redis_job_manager(redis_url: str = None) -> RedisJobManager:
    """Initialize Redis job manager with custom URL."""
    global _redis_job_manager
    _redis_job_manager = RedisJobManager(redis_url)
    return _redis_job_manager
